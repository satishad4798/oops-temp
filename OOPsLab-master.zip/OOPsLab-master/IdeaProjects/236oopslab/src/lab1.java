import java.util.Scanner;

public class lab1 {
    public static void main(String args[])
    {
        System.out.println("enter message");
        Scanner scan=new Scanner(System.in);
        String s=scan.nextLine();
        System.out.println("message is "+s);
    }

}
