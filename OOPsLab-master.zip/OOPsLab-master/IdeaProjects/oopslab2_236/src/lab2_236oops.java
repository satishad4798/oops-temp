public class lab2_236oops {
}
