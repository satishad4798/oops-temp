# ColorGame

A mini project completed while learning WebDev.

Contains raw coded files.
