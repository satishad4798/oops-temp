import java.util.Scanner;

public class myqueue {
    int size=100;
    int[] arr= new int[size];
    int top=-1;int front=-1;
    public void push(int key){
        if(top == size)
        {
            System.out.println("queue is full\n");
            return;
        }
        if(front == -1){
            front ++;
        }
        top++;
        arr[top]=key;
    }

    public void pop(){
        if(front == -1)
        {
            System.out.println("stack is empty\n");
            return;
        }

        front++;

    }
    public void traverse(){
        for(int i=front;i<=top;i++)
        {
            System.out.println(arr[i]+",");
        }
    }

    public static void main(String[] args){
        int c;
        myqueue q = new myqueue();
        Scanner input = new Scanner(System.in);
        while(true){
            System.out.println("enter 1:push 2:pop 3:loop 4:exit :");
            c=input.nextInt();
            switch(c)
            {
                case 1: {
                    System.out.println("Enter the input:");
                    Scanner input1 = new Scanner(System.in);
                    int key = input1.nextInt();
                    q.push( key);
                    break;
                }
                case 2:{
                    q.pop();
                    break;
                }
                case 3: {
                    q.traverse();
                    System.out.println("\n");
                    break;
                }
                case 4:{
                    return;
                }
            }

        }

    }
}
