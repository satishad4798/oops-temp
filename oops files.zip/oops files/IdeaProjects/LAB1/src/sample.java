import java.util.Scanner;

public class sample {

    public static void main(String args[]){

        String s;
        Scanner in= new Scanner(System.in);
        System.out.println("Enter string: ");
        s= in.nextLine();
        System.out.println("You entered "+s);
    }
}
