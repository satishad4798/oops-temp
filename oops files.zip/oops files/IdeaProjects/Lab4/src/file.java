import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class file {

    public boolean fileExists(String s)
    {
        File f = new File(s);
         return f.exists();
    }

    public boolean fileReadable(String s){


        return Files.isReadable(Paths.get(s));
    }

    public boolean fileWritable(String s){
        return Files.isWritable(Paths.get(s));
    }

    public long length(String s){
        File f = new File(s);
        return f.length();
    }
     public String getFileExtension(String s){
        String fname = new File(s).getName();
        int dotin = fname.lastIndexOf('.');

        return (dotin == -1)?"":fname.substring(dotin+1);
     }


    public static void main(String[] a){

            Scanner in = new Scanner(System.in);
            System.out.println("Enter the path name");
            String s = in.next();
             file  myf = new file();
//            boolean b;
//            b=myf.fileExists(s);
            System.out.println("File exists ? "+myf.fileExists(s));
            System.out.println("is readable? " +myf.fileReadable(s));
            System.out.println("is writable? " +myf.fileWritable(s));
            System.out.println("type of file " +myf.getFileExtension(s));
            System.out.println("length= " +myf.length(s));

    }

}

