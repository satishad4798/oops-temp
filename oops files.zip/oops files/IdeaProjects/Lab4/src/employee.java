import java.util.Arrays;
import java.util.Scanner;

public class employee {

    String name, desig,dept, email;
    int day,mon,year;
    double salary;


    public int compareAge(employee a,employee b){
        if(a.year > b.year)
        {
            return 1;
        }
        else if( a.year < b.year)
        {
            return -1;
        }
        else {
            if(a.mon > b.mon){
                return 1;
            }
            else if ( a.mon < b.mon)
            {
                return -1;
            }
            else {
                if(a.day > b.day){
                    return 1;
                }
                else if(a.day < b.day){
                    return -1;
                }
                else {
                    return 0;
                }
            }
        }
    }


    public static void main(String[] a){
        int N;
        Scanner in= new Scanner(System.in);
        System.out.println("enter N");
        N=in.nextInt();
        System.out.println("enter the no of dept");
        int d=in.nextInt();
        String[] s= new String[d];
        for(int i=0;i<d;i++)
        {
            System.out.println("enter the dept");
            s[i]=in.next();
        }
        Double[] avg = new Double[d];
        employee[] e = new employee[N];

        for(int i=0;i<N;i++){
            e[i]=new employee();
            System.out.print("Enter the name");
            e[i].name=in.next();
            System.out.print("Enter the desig");
            e[i].desig=in.next();
            System.out.println("Enter the dept");
            e[i].dept=in.next();
            System.out.println("Enter the email");
            e[i].email=in.next();
            System.out.println("Enter the dob as day month year");
            e[i].day=in.nextInt();
            e[i].mon=in.nextInt();
            e[i].year=in.nextInt();
            System.out.println("Enter the salary");
            e[i].salary=in.nextDouble();
        }
        //sort empl based on salary
        for(int i=0;i<N;i++){
            for(int j=0;j<N-i-1;j++)
            {
                if(e[i].salary > e[j].salary){

                    employee t = e[i];
                    e[i]=e[j];
                    e[j]=t;
                }
            }
        }
        int cnt=0;
        double maxsal=(double)0;
        for(int j=0;j<d;j++) {
            avg[j]=(double)0;
            for (int i = 0; i < N; i++) {
                 if (e[i].dept.compareTo(s[j]) == 0) {
                    System.out.println(e[i].name);
                    System.out.println(e[i].desig);
                    System.out.println(e[i].email);
                    System.out.println(e[i].day+e[i].mon+e[i].year);
                    System.out.println(e[i].salary);
                    avg[j]+=e[i].salary;
                    cnt++;
                }
            }
            avg[j]=avg[j]/cnt;
            System.out.println("Average sal of dept "+s[j]+"is "+String.format("%.2f",avg[j]));
            if(avg[j] > maxsal){
                maxsal=avg[j];
            }
        }
        System.out.print("Maximum avg sal is: " );
        System.out.println(String.format("%.2f",maxsal));


        //sort empl based age
        for(int i=0;i<N;i++){
            for(int j=0;j<N-i-1;j++)
            {
                if(e[i].compareAge(e[i],e[j]) <=0) {

                    employee t = e[i];
                    e[i]=e[j];
                    e[j]=t;
                }
            }
        }
        cnt=0;
        Double[] avgage=new Double[d];
        double maxage=(double)0;
        for(int j=0;j<d;j++) {
            avgage[j]=(double)0;
            for (int i = 0; i < N; i++) {
                if (e[i].dept.compareTo(s[j]) == 0) {
                    System.out.println(e[i].name);
                    System.out.println(e[i].desig);
                    System.out.println(e[i].email);
                    System.out.println(e[i].day+e[i].mon+e[i].year);
                    System.out.println(e[i].salary);
                    avgage[j]+= 2019-e[i].year;
                    cnt++;
                }
            }
            avgage[j]=avgage[j]/cnt;
            System.out.println("Average AGE of dept  "+s[j]+"is "+String.format("%.2f",avgage[j]));
            if(avgage[j] > maxage){
                maxage=avgage[j];
            }
        }
        System.out.print("Maximum avg  sal is: " );
        System.out.println(String.format("%.2f",maxage));
    }
}
