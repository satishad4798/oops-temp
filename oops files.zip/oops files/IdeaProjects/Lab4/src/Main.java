import java.util.Scanner;

abstract class shape {
    int n1,n2;
    abstract void printArea(int n1,int n2);
}

 class rectangle extends shape{



    void printArea(int n1,int n2){
        super.n1=n1;
        super.n2=n2;
       System.out.println( super.n1*super.n2 );
    }


} class circle extends shape{

    void printArea(int n1,int n2){
        super.n1=n1;
        super.n2=n2;
        System.out.println( 3.14*super.n1*super.n1 );
    }


} class tri extends shape{

    void printArea(int n1,int n2){
        super.n1=n1;
        super.n2=n2;
        System.out.println( 0.5*super.n1*super.n2 );
    }


}

public class Main {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        System.out.println("For rec");
        System.out.println("Enter num1 and num2");
        int n1=in.nextInt();
        int n2=in.nextInt();
        rectangle r1 = new rectangle();
        r1.printArea(n1,n2);
        System.out.println("For cir");
        System.out.println("Enter num1 ");
        n1=in.nextInt();

       circle c = new circle();
       c.printArea(n1,n2);
        System.out.println("For tri");
        System.out.println("Enter num1 and num2");
        n1=in.nextInt();
        n2=in.nextInt();
        tri t = new tri();
        t.printArea(n1,n2);


    }
}