import java.util.Scanner;

public class tollbooth {
    int veh;
    double amt;

    public tollbooth()
    {
        veh=0;
        amt=0;
    }

    public void payingVeh()
    {
        veh++;
        amt+=50;
    }

    public void nonpayVeh(){
        veh++;
    }
    public void dis(){
        System.out.println("veh "+veh);
        System.out.println("amt "+amt);
    }

    public static void main(String[] args){
        tollbooth t= new tollbooth();
        Scanner in= new Scanner(System.in);
        int b;
        while(true)
        {
            System.out.println("1-payVeh 2-nonpayVeh 3-exit");
            b=in.nextInt();
            if(b == 1){
                t.payingVeh();
                t.dis();
            }
            else if(b == 2){
                t.nonpayVeh();
                t.dis();
            }
            else {
                break;
            }
        }

    }
}
