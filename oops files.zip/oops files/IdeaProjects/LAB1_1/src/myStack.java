import java.util.Scanner;

public class myStack {

    int size=100;
    int[] stack= new int[size];
    int top=-1;
    public void push(int key){
        if(top == size)
        {
            System.out.println("Stack is full\n");
            return;
        }
        top++;
        stack[top]=key;
    }

    public void pop(){
        if(top == -1)
        {
            System.out.println("stack is empty\n");
            return;
        }
//        int v=top;
        top--;
//        return (Integer)stack[v];
    }
    public void traverse(){
        for(int i=0;i<=top;i++)
        {
            System.out.println(stack[i]+",");
        }
    }



    public static void main(String[] args){
        int c;
        myStack stck = new myStack();
        Scanner input = new Scanner(System.in);
        while(true){
            System.out.println("enter 1:push 2:pop 3:loop 4:exit :");
            c=input.nextInt();
             switch(c)
             {
                 case 1: {
                     System.out.println("Enter the input:");
                    Scanner input1 = new Scanner(System.in);
                    int key = input1.nextInt();
                    stck.push( key);
                    break;
                 }
                 case 2:{
                     stck.pop();
                     break;
                 }
                 case 3: {
                     stck.traverse();
                     System.out.println("\n");
                     break;
                 }
                 case 4:{
                     return;
                 }
             }

        }

    }
}
