import java.util.Scanner;

class Date{
    int day,mon,year;
    Date(int day,int mon,int year){
        this.day=day;
        this.mon=mon;
        this.year=year;
    }
}


 class TravelAgency {


        String name, PlaceVisted;
        String startDate,returnDate;

        public void print(){

            System.out.println("name: "+name+" visted Place "+PlaceVisted+" Start Date "+startDate+" Return Date "+returnDate);
        }

}

class age extends TravelAgency{
    int age;
    public age(String name,String PlaceVisited,String startDate,String returnDate,int age){
       this.age=age;
        super.name=name;
        super.PlaceVisted=PlaceVisited;
        super.returnDate=returnDate;
        super.startDate=startDate;
    }
}

class testclass{
    public static void main(String[]a){
        age[] ages= new age[5];
        String name, PlaceVisted;
        String startDate,returnDate;
        int age;
        Scanner in =new Scanner(System.in);
        for(int i=0;i<5;i++){
            System.out.println("Enter the name placeVisted,strt date,ret date,age");
            name=in.next();
            PlaceVisted=in.next();
            startDate=in.next();
            returnDate=in.next();
            age=in.nextInt();
            ages[i]=new age(name,PlaceVisted,startDate,returnDate,age);
        }
        for (int i=0;i<5;i++){
            if( ages[i].age <12){
                ages[i].print();
            }
        }
    }

}