public class employee {
    String name,desig;
    double salary;

    public employee(String name, String desig,double salary){
        this.name=name;
        this.desig=desig;
        this.salary=salary;
    }
}

class Manager extends employee{

    String dept;
     public Manager(String name,String desig,double salary,String dept){
         super(name,desig,salary);
         this.dept=dept;
     }

    void print(){
        System.out.println("mangers name: "+ super.name+" dept: "+dept+" salary: "+super.salary);
    }
}

class Executive extends Manager{

   public Executive(String name,String desig,double salary,String dept){
       super(name,desig,salary,dept);
   }
     void printStr(){

         System.out.print("Executive ");
         super.print();
     }
}

class testClass{
    public static void main(String[] a){

        Executive exec = new Executive("ram","AsstProf",33543,"cse");
        exec.printStr();
    }
}