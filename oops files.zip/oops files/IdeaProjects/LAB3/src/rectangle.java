import java.util.Scanner;

public class rectangle {

    double width,length,area;
    String color;

    //set_length set_width set_color find_area

    public void set_width(double x){
        width=x;
    }

    public void set_length(double x){
        length=x;
    }
    public void set_color(String st){
        color=st;
    }

    public double find_area(){
        area=length*width;
        return area;
    }

    public static void main(String[] a){
        double n1,n2;
        rectangle rec1= new rectangle();
        rectangle rec2= new rectangle();
        Scanner in=new Scanner(System.in);
        System.out.println("Enter the length1");
        n1=in.nextDouble();
        rec1.set_length(n1);
        System.out.println("Enter the width1");
        n2=in.nextDouble();
        rec1.set_width(n2);
        System.out.println("enter the color1");
        String s=in.next();
        rec1.set_color(s);

        System.out.println("Enter the length2");
        n1=in.nextDouble();
        rec2.set_length(n1);
        System.out.println("Enter the width2");
        n2=in.nextDouble();
        rec2.set_width(n2);
        System.out.println("enter the color2");
         s=in.next();
        rec2.set_color(s);

        if( (rec1.find_area() == rec2.find_area())&&(rec1.color.compareTo( rec2.color) == 0))
        {
            System.out.println("Matching rectangles");
        }
        else
        {
            System.out.println(" not Matching rectangles");
        }
    }
}
