import java.util.Scanner;

public class calci {

    int num1,num2,result;

    public void add(){
        result=num1+num2;
        System.out.println("res="+result);
    }

    public void mul(){
        result=num1*num2;
        System.out.println("res="+result);
    }
    public void sub(){
        result=num1-num2;
        System.out.println("res="+result);
    }
    public void div(){
        if(num2 == 0){
            System.out.println("Zero Exception");
            return;
        }
        result=num1/num2;
        System.out.println("res="+result);
    }

    public static void main(String[] args){

        Scanner input=new Scanner(System.in);
        calci calc=new calci();

        System.out.println("Enter Num1");
        calc.num1=input.nextInt();

        System.out.println("Enter Num2");
        calc.num2=input.nextInt();

        System.out.println("Enter the operation");

        char op=input.next().charAt(0);

        if( op == '+')
        {
            calc.add();
        }
        else if( op == '-'){
            calc.sub();
        }
        else if(op == '*'){
            calc.mul();
        }
        else if(op == '/') {
            calc.div();
        }


    }
}
