import java.util.Scanner;

public class student {
    int rollno,marks1,marks2,marks3;
    String name;

    public student() //null const
    {
    }

    public student(int r,int m1,int m2,int m3,String s){

        this.marks1=m1;
        this.marks2=m2;
        this.marks3=m3;
        this.rollno=r;
        this.name=s;
    }

    public student( student st){
        this.rollno=st.rollno;
        this.marks1=st.marks1;
        this.marks2=st.marks2;
        this.marks3=st.marks3;
        this.name=st.name;
    }

    public void display(){
        System.out.println("m1 "+this.marks1);
        System.out.println("m2 "+this.marks2);

        System.out.println("m3 "+this.marks3);
        System.out.println("roll "+this.rollno);
        System.out.println("name "+this.name);
    }

    public static void main(String[] a){

        int r,m1,m2,m3;
        String s;
        Scanner in=new Scanner(System.in);
        System.out.println("Enter the rollno");
        r=in.nextInt();
        System.out.println("Enter the m1");
        m1=in.nextInt();
        System.out.println("Enter the m2");
        m2=in.nextInt();
        System.out.println("Enter the m3");
        m3=in.nextInt();
        System.out.println("Enter the name");
        s=in.next();
        student st1=new student();
        student st2=new student(r,m1,m2,m3,s);
        student st3=new student(st2);
        Syste
            System.out.println(m.out.println("null const");
        st1.display();"p const");
        st2.display();
        System.out.println("c const");
        st3.display();



    }

}
