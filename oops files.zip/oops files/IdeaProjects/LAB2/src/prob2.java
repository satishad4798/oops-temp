import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class prob2 {
   String[] name= new String[100];

   public void sort(String[] x){
        for(int i=0;i<5;i++)
        {
            for(int j=0;j<5;j++)
            {
                if(x[i].compareTo(x[j]) > 0){
                        String s=x[i];
                        x[i]=x[j];
                        x[j]=s;

                }
            }
        }

   }

   public static void main(String[] args){

       prob2 p=new prob2();
       Scanner sc =new Scanner(System.in);
       for(int i=0;i<5;i++)
       {
           System.out.println("Enter the String\n");
           p.name[i]=sc.nextLine();
       }
       p.sort(p.name);
       for(int i=0;i<5;i++)
       {
           System.out.println(p.name[i]+"\n");
//           p.name[i]=sc.nextLine();
       }
   }

}
