public class prob1 {
    String msg;
    public prob1(String s){
        msg=s;
    }

    public static void main(String[] args){
        prob1 p= new prob1("Hello world");
        System.out.println(p.msg);
    }
}
