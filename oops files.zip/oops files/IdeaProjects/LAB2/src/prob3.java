import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class prob3 {
    public static void main(String[] args){
        String s;
        Scanner i=new Scanner(System.in);
        System.out.println("enter the String");
        s=i.nextLine();
      try{

          File a =new File("a.txt");
          PrintWriter p= new PrintWriter(a);
          p.println(""+s);
          p.close();
      }
      catch (IOException z){
          z.printStackTrace();
      }
    }

}
